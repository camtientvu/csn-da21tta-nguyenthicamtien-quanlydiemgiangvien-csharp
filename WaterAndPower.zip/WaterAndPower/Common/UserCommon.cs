﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WaterAndPower.Model;

namespace WaterAndPower.Common
{
    public class UserCommon
    {
        public static string id_taikhoan { get; set; }
        public static List<QuyenHeThongModel> models { get; set; }
    }
}
