﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectManage.Common
{
    public class ConnectionString
    {
        public const string connectionStr = "Server=.\\SQLEXPRESS;Database=QUANLYDIEM_GIANGVIEN;Trusted_Connection=True;";
    }
}
