﻿using ProjectManage.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using WaterAndPower.Common;
using WaterAndPower.Dao;
using WaterAndPower.Model;
using WaterAndPower.UserControls;

namespace WaterAndPower.Forms.Quyen
{
    public partial class Form_QuyenTaiKhoan : Form
    {
        private QuyenHeThongDao _quyenHeThongDao;
        private List<QuyenHeThongDaGanModel> _quyenHTTaiKhoanModel;
        private List<QuyenHeThongModel> _quyenHeThongModel;
        private string _idtaikhoan = "";
        public Form_QuyenTaiKhoan(string id_taikhoan)
        {
            InitializeComponent();
            _quyenHeThongDao = new QuyenHeThongDao(ConnectionString.connectionStr);
            _quyenHTTaiKhoanModel = new List<QuyenHeThongDaGanModel>();
            _quyenHeThongModel = new List<QuyenHeThongModel>();
            _idtaikhoan = id_taikhoan;
            checkBox6.Checked = true;
            LayTatCaCacQuyenCuaTaiKhoan("");
        }

        public void LayTatCaCacQuyenCuaTaiKhoan(string code)
        {
            dataGridView1.Rows.Clear();
            if(_quyenHeThongModel.Count > 0)
            {
                _quyenHeThongModel.Clear();
            }
            if (_quyenHTTaiKhoanModel.Count > 0)
            {
                _quyenHTTaiKhoanModel.Clear();
            }
            _quyenHeThongModel = _quyenHeThongDao.LayTatCaQuyenTheoIdTaiKhoan(_idtaikhoan);
            List<QuyenHeThongModel> tatcaquyens = _quyenHeThongDao.LayTatCaQuyenTheoMaCode(code);
            foreach (var quyen in tatcaquyens)
            {
                QuyenHeThongDaGanModel model = new QuyenHeThongDaGanModel()
                {
                    id = quyen.id,
                    ten_quyen = quyen.ten_quyen,
                    code = quyen.code,
                    trang_thai = false
                };
                _quyenHTTaiKhoanModel.Add(model);
            }

            foreach (var quyentaikhoan in _quyenHeThongModel)
            {
                var quyen = _quyenHTTaiKhoanModel.FirstOrDefault(x=>x.id == quyentaikhoan.id);
                if(quyen != null)
                {
                    quyen.trang_thai = true;
                }
                else
                {
                    QuyenHeThongDaGanModel model = new QuyenHeThongDaGanModel()
                    {
                        id = quyentaikhoan.id,
                        ten_quyen = quyentaikhoan.ten_quyen,
                        trang_thai = false,
                        code = quyentaikhoan.code
                    };
                    _quyenHTTaiKhoanModel.Add(model);
                }
            }
            
            if (_quyenHTTaiKhoanModel != null && _quyenHTTaiKhoanModel.Count > 0)
            {
                try
                {
                    foreach (var item in _quyenHTTaiKhoanModel)
                    {
                        DataGridViewRow newRow = new DataGridViewRow();
                        newRow.CreateCells(dataGridView1);
                        newRow.Cells[0].Value = item.id;
                        newRow.Cells[1].Value = item.ten_quyen;
                        newRow.Cells[2].Value = item.trang_thai;
                        dataGridView1.Rows.Add(newRow);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Không có dữ liệu trong hệ thống", "Thông báo");
                }
            }
            else
            {
                MessageBox.Show("Không có dữ liệu trong hệ thống", "Thông báo");
            }
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            bool isSuccess = false;
            foreach (DataGridViewRow item in dataGridView1.Rows)
            {
                if ((bool)item.Cells[2].Value == true)
                {
                    bool isExist = _quyenHeThongDao.KiemTraQuyenCuaTaiKhoan(item.Cells[0].Value.ToString(), _idtaikhoan);
                    if(!isExist)
                    {
                        int resultInsert = _quyenHeThongDao.GanQuyenChoTaiKhoan(_idtaikhoan, item.Cells[0].Value.ToString());
                        if (resultInsert == 1)
                        {
                            isSuccess = true;
                        }
                        else
                        {
                            isSuccess = false;
                        }
                    }
                }
                else
                {
                    int resultDelete = _quyenHeThongDao.XoaQuyenCuaTaiKhoan(item.Cells[0].Value.ToString(), _idtaikhoan);
                    if (resultDelete == 1)
                    {
                        isSuccess = true;
                    }
                    else
                    {
                        isSuccess = false;
                    }
                }
            }
            if(isSuccess)
            {
                MessageBox.Show("Cập nhập quyền thành công", "Thông báo");
                LayTatCaCacQuyenCuaTaiKhoan("");
            }
            else
            {
                MessageBox.Show("Đã có lỗi xẩy ra với hệ thống. Vui lòng thử lại sau", "Thông báo");
            }
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            _quyenHeThongDao.Dispose();
            this.Close();
            Form_TrangChu frm = Application.OpenForms.OfType<Form_TrangChu>().FirstOrDefault();
            frm.XuLyQuyenCuaTaiKhoan();
            var uc = (UC_TaiKhoanQuyen)frm.ActiveControl;
            if (uc != null)
            {
                uc.LayDuLieuTaiKhoan();
            }
        }

        private void Form_QuyenTaiKhoan_FormClosed(object sender, FormClosedEventArgs e)
        {
            _quyenHeThongDao.Dispose();
            this.Close();
            Form_TrangChu frm = Application.OpenForms.OfType<Form_TrangChu>().FirstOrDefault();
            frm.XuLyQuyenCuaTaiKhoan();
            var uc = (UC_TaiKhoanQuyen)frm.ActiveControl;
            if (uc != null)
            {
                uc.LayDuLieuTaiKhoan();
            }
        }

        public void LayDuLieuKhiCheckBox(string code = "")
        {
            dataGridView1.Rows.Clear();
            if (code != "")
            {
                foreach (var item in _quyenHTTaiKhoanModel)
                {
                    if(item.code.Contains(code))
                    {
                        DataGridViewRow newRow = new DataGridViewRow();
                        newRow.CreateCells(dataGridView1);
                        newRow.Cells[0].Value = item.id;
                        newRow.Cells[1].Value = item.ten_quyen;
                        newRow.Cells[2].Value = item.trang_thai;
                        dataGridView1.Rows.Add(newRow);
                    }
                }
            }
            else
            {
                foreach (var item in _quyenHTTaiKhoanModel)
                {
                    DataGridViewRow newRow = new DataGridViewRow();
                    newRow.CreateCells(dataGridView1);
                    newRow.Cells[0].Value = item.id;
                    newRow.Cells[1].Value = item.ten_quyen;
                    newRow.Cells[2].Value = item.trang_thai;
                    dataGridView1.Rows.Add(newRow);
                }
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox6.Checked = false;
            }
            LayDuLieuKhiCheckBox("Admin");
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                checkBox1.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox6.Checked = false;
            }
            LayDuLieuKhiCheckBox("Student");
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                checkBox1.Checked = false;
                checkBox2.Checked = false;
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox6.Checked = false;
            }
            LayDuLieuKhiCheckBox("Score");
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                checkBox1.Checked = false;
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox5.Checked = false;
                checkBox6.Checked = false;
            }
            LayDuLieuKhiCheckBox("Subject");
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked)
            {
                checkBox1.Checked = false;
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
                checkBox6.Checked = false;
            }
            LayDuLieuKhiCheckBox("Time");
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked)
            {
                checkBox1.Checked = false;
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
                checkBox5.Checked = false;
            }
            LayDuLieuKhiCheckBox("");
        }
    }
}
