﻿namespace WaterAndPower.Forms.SinhVien
{
    partial class Form_ThemMoiSinhVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_ThemMoiSinhVien));
            this.label3 = new System.Windows.Forms.Label();
            this.btn_saveandupdate = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_masv = new System.Windows.Forms.TextBox();
            this.txt_tensv = new System.Windows.Forms.TextBox();
            this.btn_back = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.ckb_nam = new System.Windows.Forms.CheckBox();
            this.ckb_nu = new System.Windows.Forms.CheckBox();
            this.dpk_ngaysinh = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.ckb_trangthai = new System.Windows.Forms.CheckBox();
            this.cb_nghanh = new System.Windows.Forms.ComboBox();
            this.cb_lop = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(128, 185);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 22);
            this.label3.TabIndex = 232;
            this.label3.Text = "Nghành học:";
            // 
            // btn_saveandupdate
            // 
            this.btn_saveandupdate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_saveandupdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_saveandupdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_saveandupdate.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_saveandupdate.ForeColor = System.Drawing.Color.Black;
            this.btn_saveandupdate.Image = ((System.Drawing.Image)(resources.GetObject("btn_saveandupdate.Image")));
            this.btn_saveandupdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_saveandupdate.Location = new System.Drawing.Point(379, 320);
            this.btn_saveandupdate.Name = "btn_saveandupdate";
            this.btn_saveandupdate.Size = new System.Drawing.Size(153, 41);
            this.btn_saveandupdate.TabIndex = 230;
            this.btn_saveandupdate.Text = "     Lưu";
            this.btn_saveandupdate.UseVisualStyleBackColor = true;
            this.btn_saveandupdate.Click += new System.EventHandler(this.btn_saveandupdate_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label5.Location = new System.Drawing.Point(128, 237);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 22);
            this.label5.TabIndex = 228;
            this.label5.Text = "Trạng thái:";
            // 
            // txt_masv
            // 
            this.txt_masv.Location = new System.Drawing.Point(285, 81);
            this.txt_masv.Name = "txt_masv";
            this.txt_masv.Size = new System.Drawing.Size(207, 20);
            this.txt_masv.TabIndex = 227;
            // 
            // txt_tensv
            // 
            this.txt_tensv.Location = new System.Drawing.Point(285, 107);
            this.txt_tensv.Name = "txt_tensv";
            this.txt_tensv.Size = new System.Drawing.Size(207, 20);
            this.txt_tensv.TabIndex = 226;
            // 
            // btn_back
            // 
            this.btn_back.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_back.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back.ForeColor = System.Drawing.Color.Black;
            this.btn_back.Image = ((System.Drawing.Image)(resources.GetObject("btn_back.Image")));
            this.btn_back.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_back.Location = new System.Drawing.Point(538, 320);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(153, 41);
            this.btn_back.TabIndex = 225;
            this.btn_back.Text = "     Quay lại";
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label6.Location = new System.Drawing.Point(128, 159);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 22);
            this.label6.TabIndex = 222;
            this.label6.Text = "Ngày sinh:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label4.Location = new System.Drawing.Point(128, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 22);
            this.label4.TabIndex = 223;
            this.label4.Text = "Tên sinh viên:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(128, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 22);
            this.label2.TabIndex = 224;
            this.label2.Text = "Mã sinh viên:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(271, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 22);
            this.label1.TabIndex = 221;
            this.label1.Text = "Thêm mới sinh viên";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(16, 31);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(82, 70);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 220;
            this.pictureBox2.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(50)))), ((int)(((byte)(94)))));
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(697, 10);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(10, 357);
            this.panel4.TabIndex = 219;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(50)))), ((int)(((byte)(94)))));
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 10);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(10, 357);
            this.panel3.TabIndex = 218;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(50)))), ((int)(((byte)(94)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 367);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(707, 10);
            this.panel2.TabIndex = 217;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(50)))), ((int)(((byte)(94)))));
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(707, 10);
            this.panel1.TabIndex = 216;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label7.Location = new System.Drawing.Point(128, 132);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 22);
            this.label7.TabIndex = 234;
            this.label7.Text = "Giới tính:";
            // 
            // ckb_nam
            // 
            this.ckb_nam.AutoSize = true;
            this.ckb_nam.Location = new System.Drawing.Point(285, 136);
            this.ckb_nam.Name = "ckb_nam";
            this.ckb_nam.Size = new System.Drawing.Size(48, 17);
            this.ckb_nam.TabIndex = 235;
            this.ckb_nam.Text = "Nam";
            this.ckb_nam.UseVisualStyleBackColor = true;
            this.ckb_nam.CheckedChanged += new System.EventHandler(this.ckb_nam_CheckedChanged);
            // 
            // ckb_nu
            // 
            this.ckb_nu.AutoSize = true;
            this.ckb_nu.Location = new System.Drawing.Point(339, 136);
            this.ckb_nu.Name = "ckb_nu";
            this.ckb_nu.Size = new System.Drawing.Size(40, 17);
            this.ckb_nu.TabIndex = 236;
            this.ckb_nu.Text = "Nữ";
            this.ckb_nu.UseVisualStyleBackColor = true;
            this.ckb_nu.CheckedChanged += new System.EventHandler(this.ckb_nu_CheckedChanged);
            // 
            // dpk_ngaysinh
            // 
            this.dpk_ngaysinh.Location = new System.Drawing.Point(285, 159);
            this.dpk_ngaysinh.Name = "dpk_ngaysinh";
            this.dpk_ngaysinh.Size = new System.Drawing.Size(207, 20);
            this.dpk_ngaysinh.TabIndex = 237;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label8.Location = new System.Drawing.Point(128, 211);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 22);
            this.label8.TabIndex = 238;
            this.label8.Text = "Lớp học:";
            // 
            // ckb_trangthai
            // 
            this.ckb_trangthai.AutoSize = true;
            this.ckb_trangthai.Location = new System.Drawing.Point(285, 242);
            this.ckb_trangthai.Name = "ckb_trangthai";
            this.ckb_trangthai.Size = new System.Drawing.Size(15, 14);
            this.ckb_trangthai.TabIndex = 240;
            this.ckb_trangthai.UseVisualStyleBackColor = true;
            // 
            // cb_nghanh
            // 
            this.cb_nghanh.FormattingEnabled = true;
            this.cb_nghanh.Location = new System.Drawing.Point(285, 185);
            this.cb_nghanh.Name = "cb_nghanh";
            this.cb_nghanh.Size = new System.Drawing.Size(207, 21);
            this.cb_nghanh.TabIndex = 241;
            this.cb_nghanh.SelectedIndexChanged += new System.EventHandler(this.cb_nghanh_SelectedIndexChanged);
            // 
            // cb_lop
            // 
            this.cb_lop.FormattingEnabled = true;
            this.cb_lop.Location = new System.Drawing.Point(285, 214);
            this.cb_lop.Name = "cb_lop";
            this.cb_lop.Size = new System.Drawing.Size(207, 21);
            this.cb_lop.TabIndex = 242;
            // 
            // Form_ThemMoiSinhVien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(707, 377);
            this.Controls.Add(this.cb_lop);
            this.Controls.Add(this.cb_nghanh);
            this.Controls.Add(this.ckb_trangthai);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.dpk_ngaysinh);
            this.Controls.Add(this.ckb_nu);
            this.Controls.Add(this.ckb_nam);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_saveandupdate);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_masv);
            this.Controls.Add(this.txt_tensv);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form_ThemMoiSinhVien";
            this.Text = "Form_ThemMoiSinhVien";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form_ThemMoiSinhVien_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_saveandupdate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_masv;
        private System.Windows.Forms.TextBox txt_tensv;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox ckb_nam;
        private System.Windows.Forms.CheckBox ckb_nu;
        private System.Windows.Forms.DateTimePicker dpk_ngaysinh;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox ckb_trangthai;
        private System.Windows.Forms.ComboBox cb_nghanh;
        private System.Windows.Forms.ComboBox cb_lop;
    }
}