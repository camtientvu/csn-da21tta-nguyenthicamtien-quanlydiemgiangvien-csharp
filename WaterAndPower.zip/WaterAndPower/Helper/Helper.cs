﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pharmonics19._1.Helpers
{
    class Helper
    {
        public static string[] UserData { get; set; }
    }
}
