﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaterAndPower.Model
{
    public class QuyenHeThongDaGanModel
    {
        public string id { get; set; }
        public string code { get; set; }
        public string ten_quyen { get; set; }
        public bool trang_thai { get; set; }

    }
}
