﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaterAndPower.Model
{
    public class ThoiGianChamThiModel
    {
        public int id { get; set; }
        public string id_hocky { get; set; }
        public string ma_monhoc { get; set; }
        public string ten_monhoc { get; set; }
        public string id_nghanh { get; set; }
        public string ngay_ket_thuc { get; set; }
        public string ngay_cham { get; set; }
    }
}
