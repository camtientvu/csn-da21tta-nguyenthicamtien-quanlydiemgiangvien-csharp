﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaterAndPower.Model
{
    public class HocKyModel
    {
        public string ma_hocky { get; set; }
        public string ten_hocky { get; set; }
    }
}
