﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaterAndPower.Model
{
    public class LopHocModel
    {
        public string ma_lop { get; set; }
        public string ten_lop { get; set; }
        public string id_nghanh { get; set; }
    }
}
