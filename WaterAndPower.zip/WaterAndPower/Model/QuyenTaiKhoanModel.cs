﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaterAndPower.Model
{
    public class QuyenTaiKhoanModel
    {
        public string id_quyen { get; set; }
        public string id_taikhoan{ get; set; }
    }
}
