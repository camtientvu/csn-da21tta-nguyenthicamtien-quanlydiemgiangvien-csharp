﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaterAndPower.Model
{
    public class QuyenHeThongModel
    {
        public string id { get; set; }  
        public string code { get; set; }
        public string ten_quyen { get; set; }
    }
}
